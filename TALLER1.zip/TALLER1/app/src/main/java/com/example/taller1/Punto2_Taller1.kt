import java.time.LocalDate

// Clase Empresa
class Empresa(
    val nombre: String,
    val nit: String,
    val direccion: String,
    val empleados: MutableList<Empleado> = mutableListOf(),
    val clientes: MutableList<Cliente> = mutableListOf()
) {
    fun calcularNominaTotal(): Double {
        return empleados.sumByDouble { it.salario }
    }

    fun calcularNominaPorDependencia(dependencia: Dependencia): Double {
        return dependencia.empleados.sumByDouble { it.salario }
    }

    fun obtenerPorcentajeClientesPorSexo(sexo: Char): Double {
        val totalClientes = clientes.size
        val clientesPorSexo = clientes.count { it.sexo == sexo }
        return (clientesPorSexo.toDouble() / totalClientes) * 100
    }

    fun obtenerCantidadEmpleadosPorCargo(nombreCargo: String): Int {
        return empleados.count { it.cargo.nombre == nombreCargo }
    }

    fun obtenerEmpleadoMasAntiguo(): Empleado? {
        return empleados.maxByOrNull { LocalDate.now().year - it.añoIngreso }
    }
}

// Clase Empleado
data class Empleado(
    val nombre: String,
    val documentoIdentidad: String,
    val sexo: Char,
    val correoElectronico: String,
    val salario: Double,
    val añoIngreso: Int,
    val dependencia: Dependencia,
    val cargo: Cargo,
    val subordinados: MutableList<Empleado> = mutableListOf()
) {
    fun agregarSubordinado(empleado: Empleado) {
        subordinados.add(empleado)
    }
}

// Clase Cliente
data class Cliente(
    val nombre: String,
    val documentoIdentidad: String,
    val sexo: Char,
    val correoElectronico: String,
    val direccion: String,
    val telefono: String
)

// Clase Dependencia
data class Dependencia(
    val nombre: String,
    val empleados: MutableList<Empleado> = mutableListOf()
)

// Clase Cargo
data class Cargo(
    val nombre: String,
    val nivelJerarquico: Int
)

// Clase para gestionar la empresa
class GestorEmpresa(private val empresa: Empresa) {

    fun agregarEmpleado(empleado: Empleado) {
        empresa.empleados.add(empleado)
    }

    fun eliminarEmpleado(empleado: Empleado) {
        empresa.empleados.remove(empleado)
    }

    fun agregarCliente(cliente: Cliente) {
        empresa.clientes.add(cliente)
    }

    fun eliminarCliente(cliente: Cliente) {
        empresa.clientes.remove(cliente)
    }
}
