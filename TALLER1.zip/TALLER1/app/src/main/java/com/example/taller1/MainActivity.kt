package com.example.taller1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val dividendo = 12
        val divisor = 3
        val resultado = divisionPorRestas(dividendo, divisor)

        val resultadoTextView: TextView = findViewById(R.id.resultadoTextView)
        resultadoTextView.text = "Resultado = $dividendo / $divisor = $resultado"
    }

    private fun divisionPorRestas(dividendo: Int, divisor: Int): Int {
        if (dividendo < divisor) {
            return 0
        } else {
            return 1 + divisionPorRestas(dividendo - divisor, divisor)
        }
    }
}
